# Mind Meld Server

Express + Socket.io backend for Mind Meld: Friday Off game.

## Setup
- Run `npm install`
- Run `npm start`
