import React, { useState, useEffect } from 'react';
import { io } from 'socket.io-client';
import './index.css';

const socket = io('http://localhost:4000');

function getRandomName() {
  return 'Player' + Math.floor(Math.random() * 1000);
}

function Dice({ roll, onRoll, canRoll }) {
  return (
    <div style={{ margin: 20 }}>
      <button disabled={!canRoll} onClick={onRoll} style={{ fontSize: 24 }}>
        🎲 Roll Dice
      </button>
      {roll && <div style={{ fontSize: 48, marginTop: 10 }}>You rolled: {roll}</div>}
    </div>
  );
}

function FridayOff() {
  return (
    <div style={{ fontSize: 40, color: 'green', margin: 30 }}>
      🎉 FRIDAY OFF UNLOCKED! 🎉
    </div>
  );
}

export default function App() {
  const [room, setRoom] = useState('');
  const [team, setTeam] = useState('');
  const [player, setPlayer] = useState(getRandomName());
  const [joined, setJoined] = useState(false);
  const [state, setState] = useState(null);
  const [prompt, setPrompt] = useState('');
  const [answer, setAnswer] = useState('');
  const [canRoll, setCanRoll] = useState(false);
  const [roll, setRoll] = useState(null);
  const [fridayOff, setFridayOff] = useState(false);
  const [topTeam, setTopTeam] = useState(null);

  useEffect(() => {
    socket.on('state', setState);
    socket.on('new-round', (g) => {
      setPrompt(g.prompt);
      setAnswer('');
      setCanRoll(false);
      setRoll(null);
      setFridayOff(false);
    });
    socket.on('team-scored', ({ team, score }) => {
      // Optionally show toast
    });
    socket.on('can-roll-dice', ({ team }) => {
      setTopTeam(team);
      setCanRoll(team === teamName());
    });
    socket.on('dice-rolled', ({ team, roll, fridayOff }) => {
      setRoll(roll);
      setFridayOff(fridayOff);
    });
    return () => {
      socket.off('state');
      socket.off('new-round');
      socket.off('team-scored');
      socket.off('can-roll-dice');
      socket.off('dice-rolled');
    };
    // eslint-disable-next-line
  }, [room, team, player]);

  function teamName() {
    return team.trim();
  }

  function joinGame(e) {
    e.preventDefault();
    if (!room || !team) return;
    socket.emit('join', { room, team: teamName(), player });
    setJoined(true);
  }

  function startRound() {
    socket.emit('start', room);
  }

  function submitAnswer(e) {
    e.preventDefault();
    if (!answer) return;
    socket.emit('submit', { word: answer });
    setAnswer('');
  }

  function rollDice() {
    socket.emit('roll-dice');
  }

  return (
    <>
      <div className="dice-bg" aria-hidden="true">
        <svg width="320" height="320" viewBox="0 0 320 320" fill="none" xmlns="http://www.w3.org/2000/svg">
          <rect x="20" y="20" width="280" height="280" rx="48" fill="#7b2ff2" fillOpacity="0.14" />
          <circle cx="80" cy="80" r="26" fill="#f357a8" fillOpacity="0.18" />
          <circle cx="160" cy="80" r="26" fill="#f357a8" fillOpacity="0.18" />
          <circle cx="240" cy="80" r="26" fill="#f357a8" fillOpacity="0.18" />
          <circle cx="80" cy="160" r="26" fill="#f357a8" fillOpacity="0.18" />
          <circle cx="160" cy="160" r="26" fill="#f357a8" fillOpacity="0.18" />
          <circle cx="240" cy="160" r="26" fill="#f357a8" fillOpacity="0.18" />
        </svg>
      </div>
      <div className="game-container">
        <h1>Mind Meld: Friday Off</h1>
        {!joined ? (
          <form onSubmit={joinGame}>
            <input placeholder="Room name" value={room} onChange={e => setRoom(e.target.value)} required />
            <input placeholder="Team name" value={team} onChange={e => setTeam(e.target.value)} required />
            <input placeholder="Your name" value={player} onChange={e => setPlayer(e.target.value)} required />
            <button type="submit">Join Game</button>
          </form>
        ) : (
          <>
            <div>Room: <b>{room}</b> | Team: <b>{teamName()}</b> | You: <b>{player}</b></div>
            <button onClick={startRound} style={{ margin: 10 }}>Start New Round</button>
            {prompt && <div style={{ fontSize: 22, margin: 10 }}>Prompt: <b>{prompt}</b></div>}
            {prompt && !fridayOff && (
              <form onSubmit={submitAnswer}>
                <input value={answer} onChange={e => setAnswer(e.target.value)} placeholder="Your word..." required />
                <button type="submit">Submit</button>
              </form>
            )}
            <div className="scores">
              <h3>Scores</h3>
              {state && state.scores && Object.entries(state.scores).map(([t, s]) => (
                <div key={t} style={{ fontWeight: t === teamName() ? 'bold' : 'normal' }}>{t}: {s}</div>
              ))}
            </div>
            {canRoll && !fridayOff && <Dice roll={roll} onRoll={rollDice} canRoll={canRoll} />}
            {fridayOff && <FridayOff />}
          </>
        )}
      </div>
    </>
  );
}
