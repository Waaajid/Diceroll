# Mind Meld Client

React frontend for the Mind Meld: Friday Off game.

## Setup
- Run `npm install`
- Run `npm start` (after building with `npm run build`)
